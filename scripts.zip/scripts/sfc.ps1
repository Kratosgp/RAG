Start-Process -FilePath "sfc.exe" -ArgumentList "/scannow" -Wait

# Check the result of the scan
$sfcResult = Get-WinEvent -LogName "Microsoft-Windows-Diagnostics-Performance/Operational" | Where-Object { $_.Message -match "Windows Resource Protection found corrupt files" }

# Display result
if ($sfcResult) {
    Write-Host "System File Checker found and repaired corrupt files."
} else {
    Write-Host "System File Checker did not find any corrupt files or was unable to repair them."
}
