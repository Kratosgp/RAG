# Get the current user's username
$currentUsername = $env:USERNAME

# Prompt user for new password
$newPassword = Read-Host -Prompt "Enter the new password" -AsSecureString

# Convert secure string to plain text
$password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($newPassword))

# Reset password for the current user account
net user $currentUsername $password

if ($LastExitCode -eq 0) {
    Write-Host "Password for user '$currentUsername' has been successfully reset."
} else {
    Write-Host "Failed to reset password for user '$currentUsername'."
}