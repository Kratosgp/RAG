# Install PSWindowsUpdate module from PowerShell Gallery
Write-Host "Installing PSWindowsUpdate module..."
Install-Module -Name PSWindowsUpdate -Force -AllowClobber

# Import the PSWindowsUpdate module
Import-Module PSWindowsUpdate

# Check for available updates
Write-Host "Checking for available updates..."
$updates = Get-WindowsUpdate -MicrosoftUpdate -Verbose

if ($updates.Count -gt 0) {
    # Install available updates
    Write-Host "Installing updates..."
    Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -Verbose
} else {
    Write-Host "No updates available."
}
