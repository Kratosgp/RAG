$fip = $ip
$username = "Admin"
$password = ConvertTo-SecureString "Demo@1234" -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential($username,$password)

$restart = {Restart-Computer -Force}
$service = {Get-Service}

$choice = $action

if ($choice -eq 'restart') {
    $script = $restart
} elseif ($choice -eq 'service') {
    $script = $service
} else {
    Write-Host "Invalid choice"
    exit
}

Invoke-Command -ComputerName $fip -Credential $cred -ScriptBlock $script