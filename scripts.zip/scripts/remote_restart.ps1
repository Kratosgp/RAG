$fip = "192.168.1.10"
$username = "Admin"
$password = ConvertTo-SecureString "Demo@1234" -AsPlainText -Force

$cred = New-Object System.Management.Automation.PSCredential($username,$password)

$script = {Restart-Computer -Force}

Invoke-Command -ComputerName $fip -Credential $cred -ScriptBlock $script