# Get the current user's username
$currentUsername = $env:USERNAME

# Prompt user for old password
$oldPassword = Read-Host -Prompt "Enter your current password" -AsSecureString

# Convert secure string to plain text
$oldPasswordText = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($oldPassword))

# Validate old password
$oldPasswordCorrect = Test-UserPassword -UserName $currentUsername -Password $oldPasswordText

if ($oldPasswordCorrect) {
    # Prompt user for new password
    $newPassword = Read-Host -Prompt "Enter the new password" -AsSecureString

    # Convert secure string to plain text
    $password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($newPassword))

    # Reset password for the current user account
    net user $currentUsername $password

    if ($LastExitCode -eq 0) {
        Write-Host "Password for user '$currentUsername' has been successfully reset."
    } else {
        Write-Host "Failed to reset password for user '$currentUsername'."
    }
} else {
    Write-Host "Incorrect old password. Please try again."
}

# Function to validate user password
function Test-UserPassword {
    param (
        [string]$UserName,
        [string]$Password
    )

    $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential -ArgumentList $UserName, $securePassword

    try {
        $null = Get-WmiObject Win32_UserAccount -Filter "Name='$UserName'" -Credential $credential -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}
