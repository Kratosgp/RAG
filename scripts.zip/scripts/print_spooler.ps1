# Restart Print Spooler service
Restart-Service Spooler

# Check service status after restart
$spoolerStatus = Get-Service Spooler
if ($spoolerStatus.Status -eq "Running") {
    Write-Host "Print Spooler service restarted successfully."
} else {
    Write-Host "Failed to restart Print Spooler service."
}
