#1# Removing recycle bin files

$Path = 'C' + ':\$Recycle.Bin'
Get-ChildItem $Path -Force -Recurse -ErrorAction SilentlyContinue | Remove-Item -Recurse -Exclude *.ini -ErrorAction SilentlyContinue
write-Host "All the necessary data removed from recycle bin successfully" -ForegroundColor Green  


#2# Remove Temp files from various locations

write-Host "Erasing temporary files from various locations" -ForegroundColor Yellow  
$Path1 = 'C' + ':\Windows\Temp'
Get-ChildItem $Path1 -Force -Recurse -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue  

$Path2 = 'C' + ':\Windows\Prefetch'
Get-ChildItem $Path2 -Force -Recurse -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue  



# Clearing app cache data files
$Path3 = 'C' + ':\Users\HARI\AppData\Local\Temp'
Get-ChildItem $Path4 -Force -Recurse -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
write-Host "removed all the temp files successfully" -ForegroundColor Green

 

#3# Using Disk cleanup Tool  

write-Host "Using Disk cleanup Tool" -ForegroundColor Yellow  

# Run the Disk Cleanup tool with the specified sagerun parameter

cleanmgr /sagerun:1 | out-Null  

# Emit a beep sound using ASCII code 7

Write-Host "$([char]7)"  
Sleep 5
write-Host "Disk Cleanup Successfully done" -ForegroundColor Green
Sleep 10